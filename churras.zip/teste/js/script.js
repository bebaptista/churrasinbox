function mostraReceitas() {
	var texto = document.getElementById("text-receita");

	// Changes the style to show the text
	if (texto.style.display == "block") {
		texto.style.display = "none";
	} else {
		texto.style.display = "block";
	}
}
function mostraReceitas2() {
	var texto = document.getElementById("text-receita2");

	// Changes the style to show the text
	if (texto.style.display == "block") {
		texto.style.display = "none";
	} else {
		texto.style.display = "block";
	}
}
function mostraReceitas3() {
	var texto = document.getElementById("text-receita3");

	// Changes the style to show the text
	if (texto.style.display == "block") {
		texto.style.display = "none";
	} else {
		texto.style.display = "block";
	}
}
function mostraCarnes() {
	var texto = document.getElementById("text-carnes");

	// Changes the style to show the text
	if (texto.style.display == "block") {
		texto.style.display = "none";
	} else {
		texto.style.display = "block";
	}
}

function mostraModos() {
	var texto = document.getElementById("text-mod");

	// Changes the style to show the text
	if (texto.style.display == "block") {
		texto.style.display = "none";
	} else {
		texto.style.display = "block";
	}
}

function mostraDicas() {
	var texto = document.getElementById("text-dicas");

	// Changes the style to show the text
	if (texto.style.display == "block") {
		texto.style.display = "none";
	} else {
		texto.style.display = "block";
	}
}

function mostraCombinações() {
	var texto = document.getElementById("text-combinacoes");

	// Changes the style to show the text
	if (texto.style.display == "block") {
		texto.style.display = "none";
	} else {
		texto.style.display = "block";
	}
}